package distancepublisher;

public interface DistancePublish {

	public int publishDistance(String origin, String dest);
}
