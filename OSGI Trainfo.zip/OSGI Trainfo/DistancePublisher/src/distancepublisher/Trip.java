package distancepublisher;

public class Trip {

	String origin;
	String dest;
	
	
	
	
	public Trip(String origin, String dest) {
		super();
		this.origin = origin;
		this.dest = dest;
	}
	
	
}
