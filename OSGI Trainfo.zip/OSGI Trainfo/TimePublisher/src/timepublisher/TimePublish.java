package timepublisher;

import models.Train;

public interface TimePublish {

	public void publishTime(int distance, Train train);
}
