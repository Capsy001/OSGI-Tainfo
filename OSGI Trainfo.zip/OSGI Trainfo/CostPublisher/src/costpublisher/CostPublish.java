package costpublisher;

import models.Train;

public interface CostPublish {

	public double publishCost(Train train, int cls);
}
